# Structurizr CLI

This GitHub repository contains the Structurizr CLI - a command line utility for Structurizr, designed to be used in conjunction with the [Structurizr DSL](https://github.com/structurizr/dsl).

- [Documentation](https://docs.structurizr.com/cli)